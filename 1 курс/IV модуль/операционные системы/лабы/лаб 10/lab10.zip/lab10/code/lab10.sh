backup=/home/asmaslova/backup
cp lab10.sh ${backup}/lab10.sh
tar -cvf ${backup}/lab10 ${backup}
