echo "Enter the arguments"
read a b c d e f g h i j k l m n o p q r s t u v trash
echo "Your arguments: "
echo ${a}
echo ${b}
echo ${c}
echo ${d}
echo ${e}
echo ${f}
echo ${g}
echo ${h}
echo ${i}
echo ${j}
echo ${k}
echo ${l}
echo ${m}
echo ${n}
echo ${o}
echo ${p}
echo ${q}
echo ${r}
echo ${s}
echo ${t}
echo ${u}
echo ${v}
